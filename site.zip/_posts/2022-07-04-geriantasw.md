---
title: Shao Wei SG trainer straight Geriant_asw
categories:
- Singapore
- Trainer
feature_image: "https://picsum.photos/2560/600?image=872"
---

Shao Wei SG trainer straight [Geriant_asw](https://instagram.com/geriant_asw)

<!-- more -->

![Geriant_ASW](https://i.ibb.co/3y8frNs/geriant-asw-str8-trainer-6211491-mp4-marked-mp41.jpg)


Available for trade or part of our [NFT access pass](https://opensea.io/collection/thevinylshacktastycollection?search%5BsortAscending%5D=true&search%5BsortBy%5D=PRICE&search%5Btoggles%5D%5B0%5D=BUY_NOW)
